import React, { Component } from "react";
import "./footer.css";
 
class Footer extends Component {
  render() {
    return (
      <div>
        
        <footer>
          <div>
          <div className="media-body">
            <h5 className="media-heading">
              <a href="http://image.msmail.morganstanley.com/lib/fe9213737760007f72/m/1/15187577-fc06-4d34-a424-d0119e06390b.pdf" target="_blank">Terms and Conditions</a>
              </h5>
            </div>
          </div>
       </footer>



      </div>
    );
  }
}
 
export default Footer;