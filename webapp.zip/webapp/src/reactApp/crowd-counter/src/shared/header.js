import React, { Component } from "react"; 
import './header.css';

class Header extends Component {
  render() {
    return (

        <nav className="navbar navbar-default header-container">
            <div className="container-fluid header-navbar">
                <div className="navbar-header">
                    <span className="header-header-label"><p><span className="company-name">Morgan Stanley</span><span className="project-name"> CROWD COUNTER </span></p></span>
                </div>
                
                <div className="collapse navbar-collapse" aria-expanded="false" aria-hidden="true">
                    <ul className="nav navbar-nav navbar-right">
                        <li className=""><a  href="#/">Home</a></li>
                        <li className="left-border-nav"><a href="#/stuff">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>





    );
  }
}
 
export default Header;