import React, { Component } from "react";
import {Route, HashRouter} from "react-router-dom";


import './App.css';
import Header from "./shared/header"
import Footer from "./shared/footer"
//import Contact from ".pages/contact";

import StreamVideo from "./pages/streamVideo";
import Stats from "./pages/stats";

function App() {

    
    return (
      <table width="100%">
        <tbody>
        <tr>
          <td className="header">
            <Header></Header>
          </td>
        </tr>

        <tr>
          <td className="body">
            <HashRouter>
              <Route path="/" component={StreamVideo}/>
              <Route path="/stuff" component={Stats}/>
              <Route path="/contact" component={Stats}/>
            </HashRouter>
          </td>
        </tr>

        <tr>
          <td className="footer">
            <Footer></Footer>
          </td>
        </tr>
        </tbody>
      </table>
    );
  }

  
export default App;