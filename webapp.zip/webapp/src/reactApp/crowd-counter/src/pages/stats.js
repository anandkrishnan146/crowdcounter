import React, { Component } from "react";
 
class Stats extends Component {
  render() {
    return (
      <div>
        <h2>STATISTICS HERE</h2>
      </div>
    );
  }
}
 
export default Stats;