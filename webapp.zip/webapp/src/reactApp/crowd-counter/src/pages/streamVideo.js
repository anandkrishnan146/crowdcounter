import React, { Component } from "react";
 
class StreamVideo extends Component {
  render() {
    return (
      <div className="row">
        <div className="col-md-8 col-lg-8">
          <video width="100%" height="600px" autoPlay="{true}" id="videoElement">
          </video>
        </div>
        <div className="col-md-4 col-lg-4">
          
        <table className="table table-sm">
          <tbody>
            <tr>
              <th scope="row" align="right"> Total Capacity </th>
              <td>350</td>
            </tr>
            <tr>
              <th scope="row"  align="right">Current Crowd</th>
              <td>340</td>
            </tr>
            <tr>
              <th scope="row"  align="right">Status</th>
              <td >Almost Occupied Fully</td>
            </tr>
          </tbody>
        </table>

        </div>
      </div>
    );
  }

  componentDidMount(){
    let video = document.querySelector("#videoElement");
    if (navigator.mediaDevices.getUserMedia && video) {
      navigator.mediaDevices.getUserMedia({ video: true, audio: false })
        .then(function (stream) {
          video.srcObject = stream;
        })
        .catch(function (err0r) {
          console.log("Something went wrong!");
        });
    }
   }
}
 
export default StreamVideo;